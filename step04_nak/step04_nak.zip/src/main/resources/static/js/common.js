/**
 * 
 */
 console.log("common.js loading");