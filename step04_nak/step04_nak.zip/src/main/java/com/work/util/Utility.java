package com.work.util;

public class Utility {
	public static String getCurrentDate() {
		return "2021-07-15";
	}

}
