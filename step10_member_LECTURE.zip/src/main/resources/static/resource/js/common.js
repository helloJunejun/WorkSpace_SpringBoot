/**
 * common.js
 */
 console.log("common.js loading");